UPDATE `#__menu` SET `title` = 'com_fabrik_lists' WHERE `title` = 'Lists' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_forms' WHERE `title` = 'Forms' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_groups' WHERE `title` = 'Groups' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_elements' WHERE `title` = 'Elements' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_visualizations' WHERE `title` = 'Visualizations' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_packages' WHERE `title` = 'Packages' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_connections' WHERE `title` = 'Connections' AND `path` LIKE 'fabrik%';
UPDATE `#__menu` SET `title` = 'com_fabrik_schedule' WHERE `title` = 'Schedule' AND `path` LIKE 'fabrik%';