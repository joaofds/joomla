ALTER TABLE `#__fabrik_joins` CHANGE `table_id` `list_id` INT( 6 ) NOT NULL;
ALTER TABLE '#__fabrik_ratings CHANGE `tableid` `listid` INT( 6 ) NOT NULL;