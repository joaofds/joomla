ALTER TABLE `#__fabrik_form_sessions` MODIFY `data` MEDIUMTEXT;

ALTER TABLE `#__fabrik_elements` MODIFY `params` MEDIUMTEXT;
